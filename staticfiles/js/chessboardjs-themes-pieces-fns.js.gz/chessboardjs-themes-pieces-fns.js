alpha_piece_theme = function(piece){ return chsspieces["alpha"][piece][0]; };
chess24_piece_theme = function(piece){ return chsspieces["chess24"][piece][0]; };
dilena_piece_theme = function(piece){ return chsspieces["dilena"][piece][0]; };
leipzig_piece_theme = function(piece){ return chsspieces["leipzig"][piece][0]; };
metro_piece_theme = function(piece){ return chsspieces["metro"][piece][0]; };
symbol_piece_theme = function(piece){ return chsspieces["symbol"][piece][0]; };
uscf_piece_theme = function(piece){ return chsspieces["uscf"][piece][0]; };
wikipedia_piece_theme = function(piece){ return chsspieces["wikipedia"][piece][0]; };
